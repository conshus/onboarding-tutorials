# Starlight Starter Kit: Basics

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/fork/github/conshus/onboarding-tutorials/tree/main/00-starter-tutorial/)

or download locally and run `npm install && npm run dev`

In the preview, there will be a toolbar in the bottom middle of the page.
Click the Vonage logo for the instructions.

<img width="563" alt="image" src="https://github.com/user-attachments/assets/64a511dd-55c3-497c-9378-97c11465307c">



[![Built with Starlight](https://astro.badg.es/v2/built-with-starlight/tiny.svg)](https://starlight.astro.build)
