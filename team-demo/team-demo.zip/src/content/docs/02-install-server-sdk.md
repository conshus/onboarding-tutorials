---
title: Install Server SDK
---

Type this command into the Terminal to install the Vonage Node Server SDK

```js
npm install @vonage/server-sdk
```
