---
title: Run the Code
---

Now it is time to send the SMS.

Run this command in the Terminal

```js
node send-sms.js
```
