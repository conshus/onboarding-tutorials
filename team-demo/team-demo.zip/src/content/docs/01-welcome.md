---
title: Welcome
description: A guide in my new Starlight docs site.
---

# The Messages API

The [Messages API](https://developer.vonage.com/en/messages/overview) provides the ability to send messages to various channels, including Facebook Messenger, SMS, WhatsApp and Viber. This task looks at using the Messages API to send an SMS message.
